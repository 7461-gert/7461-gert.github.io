Do use the issues tab to report an issue. 
