# Snel aan de slag met Github Pages version 1.2a

### [> Naar de handleiding <](http://piersoncollege.github.io/html/)

![Homer... help?](http://i.imgur.com/aqeoWiJ.gif)
